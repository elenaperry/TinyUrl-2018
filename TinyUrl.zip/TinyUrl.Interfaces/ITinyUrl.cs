﻿namespace TinyUrl.Interfaces
{
    public interface IUrl
    {
        int Id { get; set;}
        string LongUrl { get; set; }
    }
}
